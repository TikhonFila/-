﻿namespace NFTBlockchain.Infrastructure;

public static class Application
{
    public static IServiceProvider ServiceProvider { get; set; }
}