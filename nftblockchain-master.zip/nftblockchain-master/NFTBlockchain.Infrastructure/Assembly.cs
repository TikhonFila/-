﻿using System.Runtime.CompilerServices;

[assembly:InternalsVisibleTo("NFTBlockchain.Domain")]
