﻿namespace NFTBlockchain.Infrastructure.Models;

public record NFTTransfer(string WorkOfArt, string From, string To);