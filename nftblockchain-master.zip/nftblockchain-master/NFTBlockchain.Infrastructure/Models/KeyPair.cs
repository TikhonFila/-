﻿namespace NFTBlockchain.Infrastructure.Models;

public record KeyPair(string PublicKey, string PrivateKey);