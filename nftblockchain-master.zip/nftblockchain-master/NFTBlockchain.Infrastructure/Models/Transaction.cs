﻿namespace NFTBlockchain.Infrastructure.Models;

internal record Transaction(string From, string To, long Amount);